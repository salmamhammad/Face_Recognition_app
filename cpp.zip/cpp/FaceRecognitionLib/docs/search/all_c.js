var searchData=
[
  ['savepgmfile',['savePGMfile',['../pgm_8c.html#a29b046898127da73e05d709e436c7377',1,'savePGMfile(const char *filename, PGMImage *img):&#160;pgm.c'],['../pgm_8h.html#a29b046898127da73e05d709e436c7377',1,'savePGMfile(const char *filename, PGMImage *img):&#160;pgm.c']]],
  ['sortindexes',['sortIndexes',['../_tools_8h.html#a2ad967ddeaa865f647c984122e694113',1,'Tools.h']]]
];
