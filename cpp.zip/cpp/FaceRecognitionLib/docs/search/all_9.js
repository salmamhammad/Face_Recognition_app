var searchData=
[
  ['n_5fpixels',['n_pixels',['../class_facebase.html#ac437c7af0d7c56e350fbeae7fb805fda',1,'Facebase']]],
  ['numcomponents',['numComponents',['../class_facebase.html#a2402dcd70b4899aea06bbff729ac08f1',1,'Facebase']]]
];
