var searchData=
[
  ['blue',['blue',['../struct_r_g_b___i_n_t.html#a8c740fbe05d907dfafb78c0521dbf840',1,'RGB_INT']]]
];
