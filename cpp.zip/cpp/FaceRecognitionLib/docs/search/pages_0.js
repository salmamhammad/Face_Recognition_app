var searchData=
[
  ['face_20recognition_20library',['Face Recognition Library',['../index.html',1,'']]]
];
