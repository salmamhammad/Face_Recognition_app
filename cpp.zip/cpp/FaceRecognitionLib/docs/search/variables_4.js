var searchData=
[
  ['green',['green',['../struct_r_g_b___i_n_t.html#ac7dd14219c9f70ae3d7b299508ef74f0',1,'RGB_INT']]]
];
