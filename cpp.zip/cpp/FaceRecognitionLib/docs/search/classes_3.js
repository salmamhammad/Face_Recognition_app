var searchData=
[
  ['pca',['PCA',['../class_p_c_a.html',1,'']]],
  ['pgmstructure',['PGMstructure',['../struct_p_g_mstructure.html',1,'']]]
];
