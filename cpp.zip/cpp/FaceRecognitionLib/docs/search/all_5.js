var searchData=
[
  ['getpgmfile',['getPGMfile',['../pgm_8c.html#af0bd903aa282469df103d2d14d2e8d28',1,'getPGMfile(const char *filename, PGMImage *img):&#160;pgm.c'],['../pgm_8h.html#af0bd903aa282469df103d2d14d2e8d28',1,'getPGMfile(const char *filename, PGMImage *img):&#160;pgm.c']]],
  ['green',['green',['../struct_r_g_b___i_n_t.html#ac7dd14219c9f70ae3d7b299508ef74f0',1,'RGB_INT']]]
];
