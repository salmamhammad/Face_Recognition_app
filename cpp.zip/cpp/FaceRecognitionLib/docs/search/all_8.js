var searchData=
[
  ['main',['main',['../main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['max',['MAX',['../pgm_8h.html#a392fb874e547e582e9c66a08a1f23326',1,'pgm.h']]],
  ['maxval',['maxVal',['../struct_p_g_mstructure.html#a1385f4396ac8af06c5e68739e85183fa',1,'PGMstructure']]],
  ['mu',['mu',['../class_p_c_a.html#a6642cff6e47deeddaf082f233b982dee',1,'PCA']]]
];
