var searchData=
[
  ['maxval',['maxVal',['../struct_p_g_mstructure.html#a1385f4396ac8af06c5e68739e85183fa',1,'PGMstructure']]],
  ['mu',['mu',['../class_p_c_a.html#a6642cff6e47deeddaf082f233b982dee',1,'PCA']]]
];
