var searchData=
[
  ['pca_2ecpp',['PCA.cpp',['../_p_c_a_8cpp.html',1,'']]],
  ['pca_2eh',['PCA.h',['../_p_c_a_8h.html',1,'']]],
  ['pgm_2ec',['pgm.c',['../pgm_8c.html',1,'']]],
  ['pgm_2eh',['pgm.h',['../pgm_8h.html',1,'']]]
];
