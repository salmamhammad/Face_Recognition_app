var searchData=
[
  ['getpgmfile',['getPGMfile',['../pgm_8c.html#af0bd903aa282469df103d2d14d2e8d28',1,'getPGMfile(const char *filename, PGMImage *img):&#160;pgm.c'],['../pgm_8h.html#af0bd903aa282469df103d2d14d2e8d28',1,'getPGMfile(const char *filename, PGMImage *img):&#160;pgm.c']]]
];
