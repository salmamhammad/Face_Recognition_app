var searchData=
[
  ['u',['U',['../class_l_d_a.html#a9cd6f0025b811066ae177731d6893f9c',1,'LDA::U()'],['../class_p_c_a.html#ad00af403af5a09ea7d13316a9c42be0a',1,'PCA::U()']]]
];
