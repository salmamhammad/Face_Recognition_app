var searchData=
[
  ['facebase',['Facebase',['../class_facebase.html',1,'']]],
  ['facebase_2ecpp',['Facebase.cpp',['../_facebase_8cpp.html',1,'']]],
  ['facebase_2eh',['Facebase.h',['../_facebase_8h.html',1,'']]],
  ['fisherfaces',['Fisherfaces',['../class_fisherfaces.html',1,'Fisherfaces'],['../main_8cpp.html#a477ffd416d99dcf7c84fb38d7305ab6f',1,'fisherfaces():&#160;main.cpp']]],
  ['fisherfaces_2ecpp',['Fisherfaces.cpp',['../_fisherfaces_8cpp.html',1,'']]],
  ['fisherfaces_2eh',['Fisherfaces.h',['../_fisherfaces_8h.html',1,'']]],
  ['face_20recognition_20library',['Face Recognition Library',['../index.html',1,'']]]
];
