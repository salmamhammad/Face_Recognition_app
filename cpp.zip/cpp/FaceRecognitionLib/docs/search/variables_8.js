var searchData=
[
  ['red',['red',['../struct_r_g_b___i_n_t.html#a0a54e5a2029532d66a1047d060823b2b',1,'RGB_INT']]]
];
